// Statik demo: src/ klasörünü dist/ altına kopyalar.
const fs = require('fs');
const path = require('path');
const src = path.join(__dirname, 'src');
const out = path.join(__dirname, 'dist');
if (!fs.existsSync(path.join(src, 'index.html'))) {
  console.error('HATA: src/index.html bulunamadı');
  process.exit(1);
}
fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(src, out, { recursive: true });
console.log('Build tamam. dist içeriği:', fs.readdirSync(out).join(', '));
