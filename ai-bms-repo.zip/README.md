# AI-BMS demo

Yapı:
```
/ (depo kökü)
├─ src/            demo dosyaları (index.html, favicon.svg, robots.txt)
├─ build.js        src/ → dist/ kopyalar
├─ package.json    "build": "node build.js"
├─ vercel.json     buildCommand=npm run build, outputDirectory=dist
└─ .gitignore
```

## Vercel ayarları (GitHub bağlantısı)
- Framework Preset: **Other**
- Root Directory: **boş** (depo kökü)
- Build Command / Output Directory: vercel.json'dan gelir (`npm run build` / `dist`)

## Yerelde deneme
```
npm run build
npx serve dist
```

## Sorun giderme
- **404:** package.json depo kökünde değilse (iç içe klasör), Vercel'de Root Directory'yi o klasöre ayarla.
- Build logunda "Build tamam. dist içeriği: index.html, favicon.svg, robots.txt" satırı görünmeli.
